(function () {
  'use strict';

  angular
    .module('crowdsource.layout', [
      'crowdsource.layout.controllers'
    ]);

  angular
    .module('crowdsource.layout.controllers', []);
})();