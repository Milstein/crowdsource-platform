(function () {
  'use strict';

  angular
    .module('crowdsource.tasks', [
      'crowdsource.tasks.controllers',      
    ]);

  angular
    .module('crowdsource.tasks.controllers', []);
  
})();
