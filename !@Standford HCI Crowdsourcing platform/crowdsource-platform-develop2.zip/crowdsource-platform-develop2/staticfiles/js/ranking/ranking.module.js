(function () {
  'use strict';

  angular
    .module('crowdsource.ranking', [
      'crowdsource.ranking.controllers',      
      //'crowdsource.ranking.services',

    ]);

  angular
    .module('crowdsource.ranking.controllers', []);
  
//@TODO decouple the the service
//  angular
//  .module('crowdsource.ranking.services', []);
})();
