(function () {
  'use strict';

  angular
    .module('crowdsource.home', [
      'crowdsource.home.controllers',
    ]);

  angular
    .module('crowdsource.home.controllers', []);

})();