//__author__ = 'neilthemathguy'

(function () {
  'use strict';

  angular
    .module('crowdsource.tasksearch', [
      'crowdsource.tasksearch.controllers',      
    ]);

  angular
    .module('crowdsource.tasksearch.controllers', []);
  
})();




